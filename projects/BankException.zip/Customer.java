public class Customer implements Cloneable {

    private String name;
    private String email;
    private String mobile;
    private Address address;

    
    public Customer(String name, String email, String mobile, Address address) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.address = address;
    }

    
    public static class Address {

        private String line;
        private String city;
        private String pincode;

        
        public Address(String line, String city, String pincode) {
            this.line = line;
            this.city = city;
            this.pincode = pincode;
        }

        
        public String getLine() {
            return line;
        }

        public String getCity() {
            return city;
        }

        public String getPincode() {
            return pincode;
        }
    }

    
    public Address getAddress() {
        return address;
    }

   
    @Override
    public Customer clone() {

        try {
            return (Customer) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}